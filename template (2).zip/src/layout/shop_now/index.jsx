import "./style.css";
const shop_now = () => {
  return (
    <>
    <div className="show-pos">
      <br />
      <br />
      <button className="shop_now">Shop Now</button>
    </div>
    </>
  );
};
export default shop_now
