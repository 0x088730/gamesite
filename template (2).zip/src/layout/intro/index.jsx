const intro = () => {
    return (
        <div style={{color: "white",textAlign: "center", fontSize: "2vw"}}>
            Masters of the Bitcoin is a collection of 21,000 Packaged Action Figure NFTs. unique<br></br> digital collectables etched and immutable on the WAX Blockchain.
        </div>
    )
}
export default intro;