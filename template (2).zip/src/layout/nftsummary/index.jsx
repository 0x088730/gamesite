import "./style.css"
const nftsummary = () => {
    return(
        <div>   
            <p className="nftsummary_align">
            Masters of the Bitcoin is a collection of 21,000 Packaged Action Figure NFTs. unique digital<br/> collectables etched and immutable on the WAX Blockchain.
            </p>
        </div>
    )
};
export default nftsummary;