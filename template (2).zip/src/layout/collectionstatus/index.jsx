import "./style.css";
const collectionstatus = () => {
    return(
        <>
            <div className="collection-status">
                <p className="gensis">Genesis Collection</p>
            </div>
        </>
    )
}
export default collectionstatus;