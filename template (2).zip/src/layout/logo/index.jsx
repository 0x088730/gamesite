import "./style.css";
const logo = () => {
    return (
        <div style={{textAlign: "center"}}>
            <img src="./logo.png" alt="" id="logomap"/>
        </div>
    )
}
export default logo;