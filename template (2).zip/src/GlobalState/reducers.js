import { combineReducers } from 'redux';
import user from './UserReducer';
export const rootReducer = combineReducers({
    user
});
